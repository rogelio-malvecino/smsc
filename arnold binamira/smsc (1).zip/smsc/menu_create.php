<div class="createcontainer">
	<table class="rap">
		<thead><td colspan="2" align="center"><b>ADD NEW MENU</b></td></thead>
		
		<tr><td>Code: </td><td><input type="text" size="30" id="menuCode" height="40" maxlength="30" onBlur="javascript:upper('marketCode')"/></td></tr>
		
		<tr><td>Name: </td><td><input type="text" size="30" id="menuName" height="40" onBlur="javascript:upper('marketName')"/></td></tr>
		
		<tr><td colspan="2" align="right"> <span id="buttoncreate" onClick="javascript:saveMenu()"><center>SAVE</center></span>
        </td></tr>
		</table>
</div>

     