<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Enterprise System</title>

   <link rel="stylesheet" type="text/css" href="example1.css"/>
   <script language="JavaScript" src="JSeverwing.js"></script>
   <script type="text/javascript" src="DropMenuX.js"></script>



	<link rel="stylesheet" type="text/css" href="sortable.css"/>
	<script type="text/javascript" src="sortable.js"></script>


</head>

<body>

<center>

<div class="container">
<div class="title"><p id="leftp">web site name</p><p id="rightp">hi username log out</p></div><!--title-->

<div class="header">



</div><!--header-->

<div class="navlink">

</div><!--navlink-->

<div class="content">

</div><!--content-->

</div><!--container-->


</center>


</body>
</html>
