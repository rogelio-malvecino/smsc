/*
 * PROJECT:   mygosuMenu
 * VERSION:   1.5.5
 * COPYRIGHT: (c) 2003,2004 Cezary Tomczak
 * LINK:      http://gosu.pl/dhtml/mygosumenu.html
 * LICENSE:   BSD (revised)
 */

----------------
! ABOUT
----------------

A simple TREE menu.
example1.php - auto generating menu from php array

----------------
! COMPATIBILITY
----------------

Tested on IE 6, Mozilla 1.6, Netscape 7.11, Opera 7.23, Firebird 0.7