<?php
//$mysqli=new mysqli("localhost","root","vertrigo","xymasterlist");
//$mysqli=new mysqli("localhost","root","misa_1127","xymasterlist");
$mysqli=new mysqli("localhost","arnold","misa_1127","smsc_main");
  ?>