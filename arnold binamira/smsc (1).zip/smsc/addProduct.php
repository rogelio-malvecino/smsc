
<div class="createcontainer">
		<table class="rap">
		<thead><td colspan="2" align="center"><b>ADD NEW PRODUCT</b></td></thead>
		
	
		<tr>
                <td>
                    Name: 
                </td>
                    <td><input type="text" size="30" id="cat" height="40" onBlur="javascript:upper('cat')"/>
                </td>
    	 </tr>
		
		<tr><td colspan="2" align="right"><span id="buttoncreate" onClick="javascript:saveProduct()"><center>SAVE</center></span>
        </td></tr>
		</table>
</div>
