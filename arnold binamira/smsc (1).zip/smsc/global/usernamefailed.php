<html>
<head>
	<title>System Manager</title>
	<link href="mystyle.css" rel="stylesheet" type="text/css" >
</head>
<body background="../images/background.JPG">
<table width="440" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
		<td valign="top" align="center" background="../images/bg_left.gif" bordercolor="#FFFFFF">
			<img border="0" src="../images/bg_top_left.gif" width="11" height="17">
		</td>
		<td>
			<table width="440" border="0" bgcolor="#EBEBEB" cellspacing="0" cellpadding="7" align="center">
                <tr bgcolor="#FFFFFF">
					<td>
						<table bgcolor="#CCCCCC" width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
							<tr bgcolor="#FFFFFF">
								<td height="1"></td>
							</tr>

							<tr>
								<td>
									<table width="440" border="1" cellspacing="0" cellpadding="6" bordercolor="#FF0000">
										<tr>
											<td width="22%" align="left" class="detail1" rowspan="2" bgcolor="#FFFFFF">
												&nbsp;<img align="middle" src="../images/alertFailed.gif">
												&nbsp;<? echo substr($_SESSION['SysMsg'],0,130) ?>
										  </td>
										</tr>
									</table>											
								</td>
							</tr>												
						</table>
					</td>
				</tr>

			</table>
		</td>
		<td align="left" background="../images/bg_right.gif" valign="top">
			<img border="0" src="../images/bg_top_right.gif" width="11" height="17">
		</td>
	</tr>

	<tr height="0">
		<td valign="top">
			<img border="0" src="../images/bg_bottom_left.gif" width="11" height="17">
		</td>
		<td valign="top">	
			<img border="0" src="../images/bg_bottom.gif" width="455" height="17">		
        </td>
		<td align="left">
			<img border="0" src="../images/bg_bottom_right.gif" width="11" height="17">
		</td>
	</tr>
</table>