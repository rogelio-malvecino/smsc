<?php 

$mysqlcnnt = new mysqli("localhost", "arnold","misa_1127", "smsc_main"); 
?>
