<?php
session_start(); 
include ("Functioneverwing.php");
Is_Logged_In();

$display="";


$display="
<table class='borderheading'>
<tr>
check disbursement transactions
</tr>
</table>";
echo $display;

			
?>
