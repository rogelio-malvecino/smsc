$(#hideshow).toggle(function(){
							 
	$('#hideshow').text('show');
	
	}, function() {
		
	$('#hideshow').text('Hide');
	
	}); 