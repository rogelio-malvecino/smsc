<?php 

$mysqlcnnt = new mysqli("localhost", "root","misa_1127", "smsc_main"); 
?>
