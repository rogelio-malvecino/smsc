
<div class="createcontainer">
		<table class="rap">
		<thead><td colspan="2" align="center"><b>ADD NEW REGION</b></td></thead>
		
			<tr>
                <td>
                	Code: 
                </td>
                <td>		
                	<input type="text" size="30" id="regionCode" onBlur="javascript:upper('regionCode')" maxlength="20" />
                </td>
        </tr>
        
		<tr>
                <td>
                    Name: 
                </td>
                <td>
                    <input type="text" size="30" id="regionName" height="40" onBlur="javascript:upper('regionName')"/>
                </td>
        </tr>
		
		<tr><td colspan="2" align="right"><span id="buttoncreate" onClick="javascript:regionSave()"><center>SAVE</center></span>
        </td></tr>
		</table>
</div>
