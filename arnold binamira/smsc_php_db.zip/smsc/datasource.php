<?php
//$mysqli=new mysqli("localhost","root","vertrigo","xymasterlist");
//$mysqli=new mysqli("localhost","root","misa_1127","xymasterlist");
$mysqli=new mysqli("localhost","root","1_acb*jrat_1","smsc_main");
  ?>