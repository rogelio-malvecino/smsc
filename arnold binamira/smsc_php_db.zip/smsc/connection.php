<?php 
$connect = mysql_connect("localhost","root","");
mysql_select_db("emasterlist",$connect);
		$Qry = "mysql_query";
		$Aoc = "mysql_fetch_assoc";
		$rows = "mysql_num_rows";
?>