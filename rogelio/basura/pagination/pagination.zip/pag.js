function writePages (n_pages) {
	var n_links = 5;

	// get the url of the page
	var s_fullPath = window.location;

	// extract the path, prefix, index and ext.
	var re_fileName = /([^\/]+)$/;
	var re_nameIdxExt = /^(.+?)(\d+)(\..+)$/;
	
	if (!re_fileName.exec(s_fullPath)) return;
	var s_fileName = RegExp.$1;
	var s_filePath = RegExp.leftContext;

	if (!re_nameIdxExt.exec(s_fileName)) return;
	var s_prefix = RegExp.$1,
		n_index = Number(RegExp.$2),
		s_ext = RegExp.$3;

	document.write('<table cellpadding="3" cellspacing="0" border="0" align="right"><tr>');	
	if (n_index != 1)
		document.write('<td><a href="' + s_filePath + s_prefix + 1 + s_ext + '"><img src="button_page_first.gif" alt="Go to first page" width="20" height="20" border="0"></a><a href="' + s_filePath + s_prefix + (n_index - 1) + s_ext + '"><img src="button_page_prev.gif" alt="Go to previous page" width="20" height="20" border="0"></a></td>');
	document.write('<td>Page ' + n_index + ' of ' + n_pages + '.</td>');

	if (n_links) {
		if (n_links > n_pages)
			n_links = n_pages;
		
		document.write('<td>Page: ');
		var n_sideLinks = Math.floor((n_links - 1) / 2),
			n_firstLink, n_lastLink;
		
		if (n_index + n_sideLinks >= n_pages) {
			n_firstLink = n_pages - n_links + 1;
			n_lastLink = n_pages;
		}
		else if (n_index - n_sideLinks <= 0) {
			n_firstLink = 1;
			n_lastLink = n_links;
		}
		else {
			n_firstLink = n_index - n_sideLinks;
			n_lastLink = n_firstLink + n_links - 1;
		}
		for (var i = n_firstLink; i <= n_lastLink; i++)
			document.write(i == n_index ? i + ' ' : '<a href="' + s_filePath + s_prefix + i + s_ext + '" title="Go to page ' + i + '">' + i + '</a> ');
		document.write('</td>');
	}
	
	if (n_index != n_pages)
		document.write('<td><a href="' + s_filePath + s_prefix + (n_index + 1) + s_ext + '"><img src="button_page_next.gif" alt="Go to next page" width="20" height="20" border="0"></a><a href="' + s_filePath + s_prefix + n_pages + s_ext + '"><img src="button_page_last.gif" alt="Go to last page" width="20" height="20" border="0"></a></td>');
	document.write('</tr></table>');
}